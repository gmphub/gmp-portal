export default function Home() {
  return (
    <div dangerouslySetInnerHTML={{ __html: `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
          <meta charset="utf-8"/>
          <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
          <title>gmp Academy</title>
          <link href="/gmp-portal/assets/css/main.css" rel="stylesheet"/>
          <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet"/>
      </head>
      <body>
          <header id="header">
              <div class="d-flex align-items-center">
                  <button aria-label="Toggle menu" id="menuToggle">
                      <i class="fas fa-bars"></i>
                  </button>
                  <nav class="breadcrumb">
                      <div class="breadcrumb-item">
                          <a href="/">gmp Academy</a>
                      </div>
                      <div class="breadcrumb-item active">
                          <span>Dashboard</span>
                      </div>
                  </nav>
              </div>
              <div class="d-flex align-items-center gap-2">
                  <button aria-label="Toggle theme" class="theme-toggle" id="themeToggle">
                      <i class="fas fa-moon" id="themeIcon"></i>
                  </button>
                  <div class="user-menu">
                      <div class="user-avatar" id="gmIcon">GM</div>
                      <div class="gm-dropdown">
                          <a href="/student/profile">Perfil</a>
                          <a href="/student/settings">Configurações</a>
                          <a href="/login">Sair</a>
                      </div>
                  </div>
              </div>
          </header>
          
          <div class="wrapper">
              <div class="sidebar" id="sidebar">
                  <div class="logo">
                      <img alt="gmp Academy Logo" class="logo-img" src="/gmp-portal/assets/images/Logo gmp Academy Round 2025.png"/>
                      <span class="logo-text">gmp Academy</span>
                  </div>
                  <nav class="sidebar-nav">
                      <a class="nav-item active" href="/">
                          <i class="fas fa-home"></i> Início
                      </a>
                      <a class="nav-item" href="/student/my-courses">
                          <i class="fas fa-book"></i> Meus Cursos
                      </a>
                      <a class="nav-item" href="/student/classes">
                          <i class="fas fa-chalkboard-teacher"></i> Aulas
                      </a>
                      <a class="nav-item" href="/student/progress">
                          <i class="fas fa-chart-line"></i> Progresso
                      </a>
                      <a class="nav-item" href="/student/certificates">
                          <i class="fas fa-certificate"></i> Certificados
                      </a>
                  </nav>
              </div>
              
              <main class="main-content" id="mainContent">
                  <div class="container full-width">
                      <div class="container" style="padding: 2rem;">
                          <div class="card shadow-hover animate-fade-in-up" style="background: linear-gradient(135deg, #1890ff, #52c41a); border: none; margin-bottom: 2rem; position: relative; overflow: hidden;">
                              <div class="card-body" style="position: relative; color: white; padding: 2rem; z-index: 2;">
                                  <div class="d-flex align-items-center justify-content-between" style="flex-wrap: wrap; gap: 2rem;">
                                      <div class="d-flex align-items-center gap-3">
                                          <div style="width: 60px; height: 60px; background: rgba(255,255,255,0.2); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                              <i class="fas fa-graduation-cap" style="font-size: 24px; color: white;"></i>
                                          </div>
                                          <div>
                                              <h1 style="margin: 0 0 0.5rem 0; font-weight: 700; font-size: 1.8rem;">Inglês para Iniciantes</h1>
                                              <p style="margin: 0 0 1rem 0; opacity: 0.9;">Curso completo para dominar o inglês do zero ao avançado</p>
                                              <div style="background: rgba(255,255,255,0.2); height: 8px; border-radius: 4px; margin-bottom: 0.5rem;">
                                                  <div style="width: 18%; height: 100%; background: rgba(255,255,255,0.9); border-radius: 4px;"></div>
                                              </div>
                                              <div style="font-size: 14px; opacity: 0.9;">
                                                  <strong>13 de 71 aulas concluídas</strong> • 18% do curso
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          
                          <div class="metrics-grid">
                              <div class="metric-card">
                                  <div class="metric-value">2h 45m</div>
                                  <div class="metric-label">Tempo Estudado</div>
                              </div>
                              <div class="metric-card">
                                  <div class="metric-value">13</div>
                                  <div class="metric-label">Aulas Concluídas</div>
                              </div>
                              <div class="metric-card">
                                  <div class="metric-value">4.8</div>
                                  <div class="metric-label">Avaliação</div>
                              </div>
                              <div class="metric-card">
                                  <div class="metric-value">3</div>
                                  <div class="metric-label">Certificados</div>
                              </div>
                          </div>
                      </div>
                  </div>
              </main>
          </div>
          
          <script>
              // Basic functionality
              document.getElementById('menuToggle').addEventListener('click', function() {
                  document.getElementById('sidebar').classList.toggle('collapsed');
                  document.getElementById('header').classList.toggle('sidebar-collapsed');
                  document.getElementById('mainContent').classList.toggle('sidebar-collapsed');
              });
              
              document.getElementById('themeToggle').addEventListener('click', function() {
                  document.body.classList.toggle('dark-theme');
                  const icon = document.getElementById('themeIcon');
                  if (document.body.classList.contains('dark-theme')) {
                      icon.classList.remove('fa-moon');
                      icon.classList.add('fa-sun');
                  } else {
                      icon.classList.remove('fa-sun');
                      icon.classList.add('fa-moon');
                  }
              });
              
              document.getElementById('gmIcon').addEventListener('click', function() {
                  document.querySelector('.gm-dropdown').classList.toggle('show');
              });
          </script>
      </body>
      </html>
    ` }} />
  )
}