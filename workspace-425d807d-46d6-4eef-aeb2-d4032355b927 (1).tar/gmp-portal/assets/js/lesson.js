/**
 * Lesson Page JavaScript
 * Handles dynamic lesson content, navigation, and sidebar functionality
 */
// SVGs for the sections
const sectionIcons = [
    // Explanation icon (document/pencil)
    `<svg xmlns="http://www.w3.org/2000/svg" class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,
    
    // Pronunciation icon (sound waves)
    `<svg xmlns="http://www.w3.org/2000/svg" class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>`,
    
    // Conversation icon (dialog balloon)
    `<svg xmlns="http://www.w3.org/2000/svg" class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`
];
// List of all 71 units
const units = [
    { id: 1, title: "Greetings" },
    { id: 2, title: "Alfabeto" },
    { id: 3, title: "Comprimentar alguém" },
    { id: 4, title: "Os substantivos" },
    { id: 5, title: "Plurais irregolares + regras" },
    { id: 6, title: "THE" },
    { id: 7, title: "A-AN" },
    { id: 8, title: "This that these those" },
    { id: 9, title: "Os adjetivos" },
    { id: 10, title: "A ordem dos adjetivos" },
    { id: 11, title: "Os dias da semana" },
    { id: 12, title: "Os pronomes pessoais I you he she it" },
    { id: 13, title: "Verbo TO BE afirmativo" },
    { id: 14, title: "Verbo TO BE negativo" },
    { id: 15, title: "Verbo TO BE interrogativo" },
    { id: 16, title: "Verbo TO BE interrogativo negativo" },
    { id: 17, title: "Present Simple TO WORK - afirmativo" },
    { id: 18, title: "Present Simple TO WORK - negativo" },
    { id: 19, title: "Present Simple Work interrogativo" },
    { id: 20, title: "Present simple TO WORK - interrogativo negativo" },
    { id: 21, title: "Verbo TO HAVE afirmativo" },
    { id: 22, title: "Verbo TO HAVE negativo" },
    { id: 23, title: "Verbo TO HAVE interrogativo" },
    { id: 24, title: "Verbo TO HAVE interrogativo negativo" },
    { id: 25, title: "Verbo TO HAVE com Do Does Don't Doesn't negativo e interrogativo" },
    { id: 26, title: "Verbo NEED afirmativo negativo e interrogativo" },
    { id: 27, title: "Present Continuous afirmativo" },
    { id: 28, title: "Present Continuous negativo" },
    { id: 29, title: "Present Continuous interrogativo" },
    { id: 30, title: "Present Continuous negativo interrogativo" },
    { id: 31, title: "Esquema resumido presente simple to be + outros" },
    { id: 32, title: "Quando se usa present simple" },
    { id: 33, title: "Quando se usa present continuous" },
    { id: 34, title: "Futuro com present simple" },
    { id: 35, title: "Futuro com present continuous" },
    { id: 36, title: "Futuro WILL TO WORK afirmativo" },
    { id: 37, title: "Futuro WILL TO WORK negativo" },
    { id: 38, title: "Futuro WILL TO WORK interrogativo" },
    { id: 39, title: "Future WILL - TO WORK - interrogativo negativo" },
    { id: 40, title: "Verbo CAN afirmativo negativo interrogativo" },
    { id: 41, title: "Verbo COULD afirmativo negativo interrogativo" },
    { id: 42, title: "Verbo MAY/MIGHT afirmativo negativo interrogativo" },
    { id: 43, title: "Verbo WOULD afirmativo negativo interrogativo" },
    { id: 44, title: "Verbo SHOULD afirmativo negativo interrogativo" },
    { id: 45, title: "Must" },
    { id: 46, title: "WH Questions" },
    { id: 47, title: "Dizendo a hora" },
    { id: 48, title: "Adjetivos possessivos" },
    { id: 49, title: "Pronomes possessivos" },
    { id: 50, title: "Possessive case 's" },
    { id: 51, title: "Pronomes objeto" },
    { id: 52, title: "Preposições OF, ON, IN, AT, TO, FOR, FROM" },
    { id: 53, title: "Advérbios de frequência" },
    { id: 54, title: "Rotinas diárias" },
    { id: 55, title: "Adjetivos comparativos" },
    { id: 56, title: "Adjetivos superlativos" },
    { id: 57, title: "Advérbios em ...ly" },
    { id: 58, title: "Some/Any" },
    { id: 59, title: "How much how many how long how far" },
    { id: 60, title: "Countable uncountable nouns" },
    { id: 61, title: "Quantifiers much little a bit of many a lot lots plenty few" },
    { id: 62, title: "Past Simple verbo TO BE" },
    { id: 63, title: "Past Simple verbo TO WORK" },
    { id: 64, title: "Verbo TO HAVE com DIDN'T" },
    { id: 65, title: "Irregular verbs" },
    { id: 66, title: "Past Continuous verbo TO WORK" },
    { id: 67, title: "Encontrando alguém" },
    { id: 68, title: "Países e nacionalidades" },
    { id: 69, title: "Descrevendo alguém" },
    { id: 70, title: "No avião" },
    { id: 71, title: "No hotel" }
];
// Sections for each unit
const sections = [
    { name: "Explicação", icon: 0, videoId: "dQw4w9WgXcQ", duration: "01:46" },
    { name: "Pronúncia", icon: 1, videoId: "dQw4w9WgXcQ", duration: "01:53" },
    { name: "Conversa", icon: 2, videoId: "dQw4w9WgXcQ", duration: "01:50" }
];
// Current lesson state
let currentState = {
    unitId: 1,
    sectionName: "Explicação",
    sectionIndex: 0
};
// DOM Elements
let unitsContainer;
let searchInput;
let toggleSidebarBtn;
let showSidebarBtn;
let sidebar;
// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    generateSidebarContent();
    setupEventListeners();
    updateCurrentLesson();
    
    // Only apply saved position if it exists, otherwise default to right
    const savedPosition = localStorage.getItem('sidebarPosition');
    if (savedPosition) {
        setSidebarPosition(savedPosition);
    }
    
    // Set proper default state for all controls on page load
    const collapsedControls = document.getElementById('collapsedSidebarControls');
    
    // Always hide collapsed controls on page load (sidebar starts open)
    if (collapsedControls) {
        collapsedControls.style.display = 'none';
        collapsedControls.classList.remove('position-left');
    }
    
    // Initialize navigation controls
    initializeNavigationControls();
    
    // Override hamburger menu functionality for lesson page
    overrideHamburgerMenu();
    
    console.log('Lesson page initialized');
});
/**
 * Initialize DOM elements
 */
function initializeElements() {
    unitsContainer = document.getElementById('unitsContainer');
    searchInput = document.getElementById('searchInput');
    toggleSidebarBtn = document.getElementById('toggleSidebar');
    showSidebarBtn = document.getElementById('showSidebarBtn');
    sidebar = document.getElementById('lessonSidebar');
    
    console.log('Initialized lesson elements:', {
        unitsContainer: !!unitsContainer,
        searchInput: !!searchInput,
        toggleSidebarBtn: !!toggleSidebarBtn,
        showSidebarBtn: !!showSidebarBtn,
        sidebar: !!sidebar
    });
}
/**
 * Initialize navigation controls
 */
function initializeNavigationControls() {
    // Setup navigation buttons
    const prevBtn = document.querySelector('.nav-previous');
    const nextBtn = document.querySelector('.nav-next');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', goToPreviousLesson);
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', goToNextLesson);
    }
    
    // Update button states
    updateNavigationButtons();
}
/**
 * Generate the sidebar content with all units
 */
function generateSidebarContent() {
    if (!unitsContainer) return;
    
    unitsContainer.innerHTML = '';
    
    units.forEach((unit, index) => {
        const unitElement = createUnitElement(unit, index);
        unitsContainer.appendChild(unitElement);
    });
    
    // Expand the first unit by default
    const firstUnit = unitsContainer.querySelector('.lesson-module');
    if (firstUnit) {
        firstUnit.classList.add('expanded');
    }
}
/**
 * Create a unit element with all its lessons
 */
function createUnitElement(unit, index) {
    const unitDiv = document.createElement('div');
    unitDiv.className = 'lesson-module';
    unitDiv.setAttribute('data-unit-id', unit.id);
    
    // Calculate progress (for demo, first 3 units have some progress)
    const progress = index < 3 ? Math.random() * 100 : 0;
    const progressText = progress > 0 ? `${Math.round(progress)}%` : '';
    
    unitDiv.innerHTML = `
        <div class="module-header">
            <div style="display: flex; align-items: center;">
                <div class="module-number">${unit.id}</div>
                <div>
                    <h4>${unit.title}</h4>
                    <span>3 aulas</span>
                </div>
            </div>
            <div class="module-progress">
                ${progress > 0 ? 
                    `<span>${progressText}</span>
                     <div class="progress-mini">
                         <div class="progress-fill" style="width: ${progress}%;"></div>
                     </div>` : 
                    `<i class="fas fa-lock" style="color: var(--border-color);"></i>`
                }
                <button class="btn-collapse">
                    <i class="fas fa-chevron-down"></i>
                </button>
            </div>
        </div>
        <div class="lesson-items">
            ${createLessonsForUnit(unit)}
        </div>
    `;
    
    // Add click event for expanding/collapsing
    const header = unitDiv.querySelector('.module-header');
    header.addEventListener('click', () => toggleUnit(unitDiv));
    
    return unitDiv;
}
/**
 * Create lesson items for a unit
 */
function createLessonsForUnit(unit) {
    return sections.map((section, index) => {
        const isLocked = unit.id > 3; // First 3 units unlocked for demo
        const isCurrent = unit.id === currentState.unitId && section.name === currentState.sectionName;
        const isCompleted = unit.id < currentState.unitId || (unit.id === currentState.unitId && index < currentState.sectionIndex);
        
        let statusClass = '';
        let statusIcon = '';
        
        if (isCurrent) {
            statusClass = 'current';
            statusIcon = '<i class="fas fa-play" style="color: white;"></i>';
        } else if (isCompleted) {
            statusClass = 'completed';
            statusIcon = '<i class="fas fa-check-circle" style="color: var(--success-green);"></i>';
        } else if (isLocked) {
            statusClass = 'locked';
            statusIcon = '<i class="fas fa-lock" style="color: var(--border-color); font-size: 8px;"></i>';
        } else {
            statusIcon = '<i class="fas fa-circle" style="color: var(--border-color); font-size: 8px;"></i>';
        }
        
        return `
            <div class="lesson-item ${statusClass}" 
                 data-unit-id="${unit.id}" 
                 data-section="${section.name}"
                 data-section-index="${index}"
                 data-video-id="${section.videoId}">
                <div class="lesson-icon">
                    ${sectionIcons[section.icon]}
                </div>
                <div class="lesson-info">
                    <div class="lesson-title">Vídeo ${section.name} - ${unit.title}</div>
                    <div class="lesson-duration">${isCurrent ? 'Tocando agora' : section.duration}</div>
                </div>
                ${statusIcon}
            </div>
        `;
    }).join('');
}
/**
 * Toggle unit expansion
 */
function toggleUnit(unitElement) {
    const isExpanded = unitElement.classList.contains('expanded');
    
    // Close all other units
    document.querySelectorAll('.lesson-module.expanded').forEach(unit => {
        if (unit !== unitElement) {
            unit.classList.remove('expanded');
        }
    });
    
    // Toggle current unit
    unitElement.classList.toggle('expanded', !isExpanded);
}
/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Search functionality
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }
    
    // Sidebar toggle
    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', toggleSidebar);
    }
    
    // Lesson item clicks
    document.addEventListener('click', function(e) {
        const lessonItem = e.target.closest('.lesson-item');
        if (lessonItem && !lessonItem.classList.contains('locked')) {
            selectLesson(lessonItem);
        }
    });
    
    // Collapsed search button
    const collapsedSearchBtn = document.getElementById('collapsedSearchBtn');
    if (collapsedSearchBtn) {
        collapsedSearchBtn.addEventListener('click', function() {
            if (searchInput) {
                searchInput.focus();
                // If sidebar is collapsed, expand it temporarily
                if (sidebar && sidebar.classList.contains('collapsed')) {
                    showSidebar();
                }
            }
        });
    }
    
    // Settings dropdown
    const settingsBtn = document.getElementById('settingsDropdown');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleSettingsDropdown();
        });
    }
    
    // Collapsed expand button
    const collapsedExpandBtn = document.getElementById('collapsedExpandBtn');
    if (collapsedExpandBtn) {
        collapsedExpandBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            showSidebar();
        });
    }
    
    // Collapsed settings dropdown
    const collapsedSettingsBtn = document.getElementById('collapsedSettingsDropdown');
    if (collapsedSettingsBtn) {
        collapsedSettingsBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            const dropdown = document.getElementById('collapsedSettingsMenu');
            dropdown.classList.toggle('show');
        });
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        const dropdown = document.getElementById('settingsMenu');
        const settingsBtn = document.getElementById('settingsDropdown');
        const collapsedDropdown = document.getElementById('collapsedSettingsMenu');
        const collapsedSettingsBtn = document.getElementById('collapsedSettingsDropdown');
        
        if (dropdown && !dropdown.contains(e.target) && !settingsBtn.contains(e.target)) {
            dropdown.classList.remove('show');
        }
        
        if (collapsedDropdown && !collapsedDropdown.contains(e.target) && !collapsedSettingsBtn.contains(e.target)) {
            collapsedDropdown.classList.remove('show');
        }
    });
}
/**
 * Handle search functionality
 */
function handleSearch(e) {
    const query = e.target.value.toLowerCase();
    const units = document.querySelectorAll('.lesson-module');
    
    units.forEach(unit => {
        const title = unit.querySelector('h4').textContent.toLowerCase();
        const lessons = unit.querySelectorAll('.lesson-title');
        
        let hasMatch = title.includes(query);
        
        // Check if any lesson matches
        lessons.forEach(lesson => {
            if (lesson.textContent.toLowerCase().includes(query)) {
                hasMatch = true;
            }
        });
        
        unit.style.display = hasMatch ? 'block' : 'none';
        
        // Expand units that have matches
        if (hasMatch && query.length > 0) {
            unit.classList.add('expanded');
        }
    });
}
/**
 * Toggle sidebar visibility
 */
function toggleSidebar() {
    if (!sidebar) return;
    
    sidebar.classList.toggle('collapsed');
    const isCollapsed = sidebar.classList.contains('collapsed');
    const savedPosition = localStorage.getItem('sidebarPosition');
    
    // Show/hide collapsed controls based on sidebar position
    const collapsedControls = document.getElementById('collapsedSidebarControls');
    const mainContent = document.querySelector('.main-content');
    const header = document.getElementById('header');
    const wrapper = document.querySelector('.wrapper');
    
    if (isCollapsed) {
        // Show collapsed controls (which include expand button)
        if (collapsedControls) {
            collapsedControls.style.display = 'flex';
            
            if (savedPosition === 'left') {
                collapsedControls.classList.add('position-left');
                
                // Position icons between left nav bar and white line
                const mainSidebar = document.getElementById('sidebar');
                if (mainSidebar && !mainSidebar.classList.contains('collapsed')) {
                    // Main sidebar is expanded (250px width)
                    collapsedControls.style.left = '260px'; // 250px + 10px
                    
                    // Increase main content margin to accommodate icons
                    if (mainContent) {
                        mainContent.style.marginLeft = '300px'; // 250px + 50px for icons
                    }
                    
                    // Adjust header width to match
                    if (header) {
                        header.style.width = 'calc(100% - 300px)';
                    }
                } else if (mainSidebar && mainSidebar.classList.contains('collapsed')) {
                    // Main sidebar is collapsed (70px width)
                    collapsedControls.style.left = '80px'; // 70px + 10px
                    
                    // Increase main content margin to accommodate icons
                    if (mainContent) {
                        mainContent.style.marginLeft = '120px'; // 70px + 50px for icons
                    }
                    
                    // Adjust header width to match
                    if (header) {
                        header.style.width = 'calc(100% - 120px)';
                    }
                } else {
                    // Default position when no main sidebar
                    collapsedControls.style.left = '10px';
                    
                    // Increase main content margin to accommodate icons
                    if (mainContent) {
                        mainContent.style.marginLeft = '60px'; // 50px for icons + 10px padding
                    }
                    
                    // Adjust header width to match
                    if (header) {
                        header.style.width = 'calc(100% - 60px)';
                    }
                }
                
                // Set wrapper background to match main content
                if (wrapper) {
                    wrapper.style.backgroundColor = 'var(--background)';
                }
                
                collapsedControls.style.right = 'auto';
            } else {
                collapsedControls.classList.remove('position-left');
                collapsedControls.style.left = ''; // Reset left positioning
                collapsedControls.style.right = '10px';
                
                // Reset main content margin and header width when sidebar is on right
                if (mainContent) {
                    mainContent.style.marginLeft = '';
                }
                if (header) {
                    header.style.width = '';
                }
                
                // Reset wrapper background
                if (wrapper) {
                    wrapper.style.backgroundColor = '';
                }
            }
        }
    } else {
        // Always hide controls when sidebar is open
        if (collapsedControls) {
            collapsedControls.style.display = 'none';
        }
        
        // Reset main content margin and header width when sidebar is open
        if (savedPosition === 'left') {
            const mainSidebar = document.getElementById('sidebar');
            if (mainContent) {
                if (mainSidebar && !mainSidebar.classList.contains('collapsed')) {
                    mainContent.style.marginLeft = '250px';
                } else if (mainSidebar && mainSidebar.classList.contains('collapsed')) {
                    mainContent.style.marginLeft = '70px';
                }
            }
            if (header) {
                if (mainSidebar && !mainSidebar.classList.contains('collapsed')) {
                    header.style.width = 'calc(100% - 250px)';
                } else if (mainSidebar && mainSidebar.classList.contains('collapsed')) {
                    header.style.width = 'calc(100% - 70px)';
                }
            }
        }
    }
    
    // Update SVG icon
    const svgIcon = toggleSidebarBtn.querySelector('svg');
    if (svgIcon) {
        if (isCollapsed) {
            // Show left arrow against vertical line (to expand)
            svgIcon.innerHTML = `
                <line x1="12" y1="2" x2="12" y2="14" stroke="currentColor" stroke-width="2"/>
                <polyline points="8,6 4,8 8,10" fill="none" stroke="currentColor" stroke-width="2"/>
            `;
        } else {
            // Show right arrow against vertical line (to collapse)
            svgIcon.innerHTML = `
                <line x1="4" y1="2" x2="4" y2="14" stroke="currentColor" stroke-width="2"/>
                <polyline points="8,6 12,8 8,10" fill="none" stroke="currentColor" stroke-width="2"/>
            `;
        }
    }
    
    // Save collapsed state
    localStorage.setItem('lesson-sidebar-collapsed', isCollapsed);
}
/**
 * Show sidebar
 */
function showSidebar() {
    if (!sidebar) return;
    
    sidebar.classList.remove('collapsed');
    
    // Always hide collapsed controls when sidebar is expanded
    const collapsedControls = document.getElementById('collapsedSidebarControls');
    if (collapsedControls) {
        collapsedControls.style.display = 'none';
    }
    
    // Update the toggle button icon in the sidebar header to collapse state
    const toggleBtn = document.getElementById('toggleSidebar');
    const svgIcon = toggleBtn ? toggleBtn.querySelector('svg') : null;
    if (svgIcon) {
        // Show right arrow against vertical line (to collapse)
        svgIcon.innerHTML = `
            <line x1="4" y1="2" x2="4" y2="14" stroke="currentColor" stroke-width="2"/>
            <polyline points="8,6 12,8 8,10" fill="none" stroke="currentColor" stroke-width="2"/>
        `;
    }
    
    // Save collapsed state
    localStorage.setItem('lesson-sidebar-collapsed', 'false');
}
/**
 * Select a lesson
 */
function selectLesson(lessonElement) {
    const unitId = parseInt(lessonElement.getAttribute('data-unit-id'));
    const sectionName = lessonElement.getAttribute('data-section');
    const sectionIndex = parseInt(lessonElement.getAttribute('data-section-index'));
    const videoId = lessonElement.getAttribute('data-video-id');
    
    // Update current state
    currentState.unitId = unitId;
    currentState.sectionName = sectionName;
    currentState.sectionIndex = sectionIndex;
    
    // Update UI
    updateCurrentLesson();
    updateLessonItems();
    
    // Update page title
    document.title = `${units[unitId - 1].title} | Vídeo ${sectionName} - gmp Academy`;
}
/**
 * Update current lesson display
 */
function updateCurrentLesson() {
    const unit = units[currentState.unitId - 1];
    const section = sections[currentState.sectionIndex];
    
    // Update lesson header
    const titleElement = document.getElementById('currentLessonTitle');
    const infoElement = document.getElementById('currentLessonInfo');
    const videoTitleElement = document.getElementById('videoTitle');
    const sectionTitleElement = document.getElementById('lessonSectionTitle');
    
    if (titleElement) {
        titleElement.textContent = `Vídeo ${currentState.sectionName} - ${unit.title}`;
    }
    
    if (infoElement) {
        infoElement.textContent = `Módulo ${currentState.unitId}: ${unit.title} • Aula ${currentState.sectionIndex + 1} de 3`;
    }
    
    if (videoTitleElement) {
        videoTitleElement.textContent = `${unit.title} - ${currentState.sectionName}`;
    }
    
    if (sectionTitleElement) {
        sectionTitleElement.textContent = `${currentState.unitId}. ${unit.title.toUpperCase()}`;
    }
    
    // Update progress
    const progressElement = document.getElementById('lessonProgressText');
    if (progressElement) {
        const completedLessons = (currentState.unitId - 1) * 3 + currentState.sectionIndex + 1;
        const totalLessons = units.length * 3;
        progressElement.textContent = `${completedLessons} de ${totalLessons} aulas concluídas`;
    }
    
    // Update navigation button states
    updateNavigationButtons();
}
/**
 * Update lesson items state
 */
function updateLessonItems() {
    const lessonItems = document.querySelectorAll('.lesson-item');
    
    lessonItems.forEach(item => {
        const unitId = parseInt(item.getAttribute('data-unit-id'));
        const sectionIndex = parseInt(item.getAttribute('data-section-index'));
        
        // Remove all status classes
        item.classList.remove('current', 'completed');
        
        // Add appropriate class
        if (unitId === currentState.unitId && sectionIndex === currentState.sectionIndex) {
            item.classList.add('current');
            
            // Update duration text
            const durationElement = item.querySelector('.lesson-duration');
            if (durationElement) {
                durationElement.textContent = 'Tocando agora';
            }
            
            // Update status icon
            const statusIcon = item.querySelector('i:last-child');
            if (statusIcon) {
                statusIcon.className = 'fas fa-play';
                statusIcon.style.color = 'white';
            }
        } else if (unitId < currentState.unitId || (unitId === currentState.unitId && sectionIndex < currentState.sectionIndex)) {
            item.classList.add('completed');
            
            // Reset duration text
            const durationElement = item.querySelector('.lesson-duration');
            const section = sections[sectionIndex];
            if (durationElement && section) {
                durationElement.textContent = section.duration;
            }
            
            // Update status icon
            const statusIcon = item.querySelector('i:last-child');
            if (statusIcon) {
                statusIcon.className = 'fas fa-check-circle';
                statusIcon.style.color = 'var(--success-green)';
            }
        }
    });
    
    // Update unit expansion - expand current unit, collapse others
    updateUnitExpansion();
}
/**
 * Update unit expansion based on current lesson
 */
function updateUnitExpansion() {
    const allUnits = document.querySelectorAll('.lesson-module');
    
    allUnits.forEach(unit => {
        const unitId = parseInt(unit.getAttribute('data-unit-id'));
        
        if (unitId === currentState.unitId) {
            // Expand current unit
            unit.classList.add('expanded');
        } else {
            // Collapse other units
            unit.classList.remove('expanded');
        }
    });
}
/**
 * Navigation functions for previous/next lessons
 */
function goToPreviousLesson() {
    // Check if we're at the very first lesson
    if (currentState.unitId === 1 && currentState.sectionIndex === 0) {
        return; // Don't navigate, stay at first lesson
    }
    
    let newUnitId = currentState.unitId;
    let newSectionIndex = currentState.sectionIndex - 1;
    
    if (newSectionIndex < 0) {
        newUnitId = Math.max(1, currentState.unitId - 1);
        newSectionIndex = 2; // Last section of previous unit
    }
    
    currentState.unitId = newUnitId;
    currentState.sectionIndex = newSectionIndex;
    currentState.sectionName = sections[newSectionIndex].name;
    
    updateCurrentLesson();
    updateLessonItems();
    updateNavigationButtons();
}
function goToNextLesson() {
    // Check if we're at the very last lesson
    if (currentState.unitId === units.length && currentState.sectionIndex === 2) {
        return; // Don't navigate, stay at last lesson
    }
    
    let newUnitId = currentState.unitId;
    let newSectionIndex = currentState.sectionIndex + 1;
    
    if (newSectionIndex > 2) {
        newUnitId = Math.min(units.length, currentState.unitId + 1);
        newSectionIndex = 0; // First section of next unit
    }
    
    currentState.unitId = newUnitId;
    currentState.sectionIndex = newSectionIndex;
    currentState.sectionName = sections[newSectionIndex].name;
    
    updateCurrentLesson();
    updateLessonItems();
    updateNavigationButtons();
}
/**
 * Update navigation button states
 */
function updateNavigationButtons() {
    const prevBtn = document.querySelector('.nav-previous');
    const nextBtn = document.querySelector('.nav-next');
    
    if (prevBtn) {
        // Disable if at first lesson
        if (currentState.unitId === 1 && currentState.sectionIndex === 0) {
            prevBtn.disabled = true;
        } else {
            prevBtn.disabled = false;
        }
    }
    
    if (nextBtn) {
        // Disable if at last lesson
        if (currentState.unitId === units.length && currentState.sectionIndex === 2) {
            nextBtn.disabled = true;
        } else {
            nextBtn.disabled = false;
        }
    }
}
/**
 * Settings dropdown functionality
 */
function toggleSettingsDropdown() {
    const dropdown = document.getElementById('settingsMenu');
    dropdown.classList.toggle('show');
}
/**
 * Set sidebar position
 */

/**
 * Set sidebar position - PORTAL6 FIXED VERSION
 */
function setSidebarPosition(position) {
    const lessonLayout = document.querySelector('.lesson-layout');
    const lessonSidebar = document.querySelector('.lesson-sidebar');
    const header = document.getElementById('header');
    
    if (!lessonLayout || !lessonSidebar) return;
    
    // Force header to full width
    if (header) {
        header.style.width = '100%';
        header.style.left = '0';
        header.style.right = '0';
    }
    
    if (position === 'left') {
        lessonLayout.style.flexDirection = 'row-reverse';
        lessonSidebar.style.borderLeft = 'none';
        lessonSidebar.style.borderRight = '1px solid var(--border-color)';
    } else {
        lessonLayout.style.flexDirection = 'row';
        lessonSidebar.style.borderRight = 'none';
        lessonSidebar.style.borderLeft = '1px solid var(--border-color)';
    }
    
    localStorage.setItem('sidebarPosition', position);
}

/**
 * Override hamburger menu functionality for lesson page
 */
function overrideHamburgerMenu() {
    const menuToggle = document.getElementById('menuToggle');
    const mainSidebar = document.getElementById('sidebar');
    const header = document.getElementById('header');
    const mainContent = document.querySelector('.main-content');
    const wrapper = document.querySelector('.wrapper');
    
    if (menuToggle && mainSidebar) {
        // Remove existing event listeners by cloning the element
        const newMenuToggle = menuToggle.cloneNode(true);
        menuToggle.parentNode.replaceChild(newMenuToggle, menuToggle);
        
        // Add new event listener that respects sidebar position
        newMenuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const savedPosition = localStorage.getItem('sidebarPosition');
            
            // Toggle main sidebar
            mainSidebar.classList.toggle('collapsed');
            
            // Update header and main content positioning based on main sidebar state
            if (mainSidebar.classList.contains('collapsed')) {
                // Main sidebar is now collapsed
                if (header) {
                    header.style.left = '70px';
                    header.style.width = 'calc(100% - 70px)';
                }
                if (mainContent) {
                    mainContent.style.marginLeft = '70px';
                    mainContent.style.width = 'calc(100% - 70px)';
                }
            } else {
                // Main sidebar is now expanded
                if (header) {
                    header.style.left = '250px';
                    header.style.width = 'calc(100% - 250px)';
                }
                if (mainContent) {
                    mainContent.style.marginLeft = '250px';
                    mainContent.style.width = 'calc(100% - 250px)';
                }
            }
            
            // Update collapsed controls positioning if units sidebar is on left and collapsed
            const collapsedControls = document.getElementById('collapsedSidebarControls');
            const lessonSidebar = document.getElementById('lessonSidebar');
            
            if (savedPosition === 'left' && lessonSidebar && lessonSidebar.classList.contains('collapsed') && collapsedControls) {
                if (mainSidebar.classList.contains('collapsed')) {
                    // Main sidebar is collapsed (70px width)
                    collapsedControls.style.left = '80px'; // 70px + 10px
                    
                    // Increase main content margin to accommodate icons
                    if (mainContent) {
                        mainContent.style.marginLeft = '120px'; // 70px + 50px for icons
                    }
                    
                    // Adjust header width to match
                    if (header) {
                        header.style.width = 'calc(100% - 120px)';
                    }
                } else {
                    // Main sidebar is expanded (250px width)
                    collapsedControls.style.left = '260px'; // 250px + 10px
                    
                    // Increase main content margin to accommodate icons
                    if (mainContent) {
                        mainContent.style.marginLeft = '300px'; // 250px + 50px for icons
                    }
                    
                    // Adjust header width to match
                    if (header) {
                        header.style.width = 'calc(100% - 300px)';
                    }
                }
                
                // Set wrapper background to match main content
                if (wrapper) {
                    wrapper.style.backgroundColor = 'var(--background)';
                }
            }
        });
    }
}
// Export functions for global access if needed
window.lessonApp = {
    goToPreviousLesson,
    goToNextLesson,
    selectLesson,
    currentState
};